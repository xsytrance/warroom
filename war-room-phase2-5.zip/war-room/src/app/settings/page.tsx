'use client';

import { useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  ArrowLeft,
  Moon,
  Bell,
  Lock,
  LogOut,
  ZapOff,
  Volume2,
  Activity,
  CheckCircle2,
} from 'lucide-react';
import Link from 'next/link';

import { WarRoomShell } from '@/components/WarRoomShell';
import { GlassCard } from '@/components/ui/GlassCard';
import { PageHeader } from '@/components/ui/SectionHeader';

interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  roleTitle: string;
  status: string;
}

function ToggleSwitch({
  enabled,
  onToggle,
}: {
  enabled: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className="relative w-11 h-6 rounded-full transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#06b6d4]/40"
      style={{ backgroundColor: enabled ? 'rgba(6,182,212,0.3)' : 'rgba(255,255,255,0.1)' }}
      aria-pressed={enabled}
      aria-label="Toggle setting"
    >
      <span
        className="absolute top-1 w-4 h-4 rounded-full transition-all duration-200"
        style={{
          backgroundColor: enabled ? '#06b6d4' : 'rgba(255,255,255,0.3)',
          left: enabled ? 'calc(100% - 1.25rem)' : '0.25rem',
        }}
      />
    </button>
  );
}

export default function SettingsPage() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [darkInterface, setDarkInterface] = useState(true);
  const [alertSignals, setAlertSignals] = useState(true);
  const [stealthMode, setStealthMode] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [soundEffects, setSoundEffects] = useState(false);

  // Load all toggles from localStorage on mount
  useEffect(() => {
    setDarkInterface(localStorage.getItem('war-room-dark') !== 'false');
    setAlertSignals(localStorage.getItem('war-room-alerts') !== 'false');
    setStealthMode(localStorage.getItem('war-room-stealth') === 'true');
    setReducedMotion(localStorage.getItem('war-room-reduced-motion') === 'true');
    setSoundEffects(localStorage.getItem('war-room-sound') === 'true');
  }, []);

  // Generic setter that syncs localStorage + dispatches storage event
  const setToggle = useCallback(
    (key: string, value: boolean, setter: (v: boolean) => void) => {
      localStorage.setItem(key, String(value));
      setter(value);
      window.dispatchEvent(new StorageEvent('storage', { key, newValue: String(value) }));
    },
    []
  );

  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => setProfile(data.user || null));
  }, []);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    window.location.href = '/login';
  };

  const toggleRows = [
    {
      key: 'dark',
      label: 'Dark Interface',
      icon: <Moon className="w-4 h-4 text-[#06b6d4]" />,
      state: darkInterface,
      setter: setDarkInterface,
      lsKey: 'war-room-dark',
    },
    {
      key: 'alerts',
      label: 'Alert Signals',
      icon: <Bell className="w-4 h-4 text-[#f59e0b]" />,
      state: alertSignals,
      setter: setAlertSignals,
      lsKey: 'war-room-alerts',
    },
    {
      key: 'stealth',
      label: 'Stealth Mode',
      icon: <Lock className="w-4 h-4 text-[#22c55e]" />,
      state: stealthMode,
      setter: setStealthMode,
      lsKey: 'war-room-stealth',
    },
    {
      key: 'motion',
      label: 'Reduced Motion',
      icon: <ZapOff className="w-4 h-4 text-[#a855f7]" />,
      state: reducedMotion,
      setter: setReducedMotion,
      lsKey: 'war-room-reduced-motion',
    },
    {
      key: 'sound',
      label: 'Sound Effects',
      icon: <Volume2 className="w-4 h-4 text-[#ef4444]" />,
      state: soundEffects,
      setter: setSoundEffects,
      lsKey: 'war-room-sound',
    },
  ];

  return (
    <WarRoomShell showNav={true}>
      <PageHeader
        title="SYSTEM CONFIG"
        subtitle="Preferences and command settings"
        action={
          <Link
            href="/profile"
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/10"
            aria-label="Back to profile"
          >
            <ArrowLeft className="w-4 h-4 text-[#e2e8f0]" />
          </Link>
        }
      />

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-4 pb-24">
        {/* User Section */}
        {profile && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <GlassCard>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-[#e2e8f0]">
                  {profile.displayName.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#e2e8f0]">
                    {profile.displayName}
                  </p>
                  <p className="text-xs text-[#94a3b8]">{profile.roleTitle}</p>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {/* Toggles */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <GlassCard padding="none" className="overflow-hidden">
            {toggleRows.map((row, index) => (
              <div
                key={row.key}
                className={`p-4 flex items-center justify-between min-h-[56px] ${
                  index < toggleRows.length - 1 ? 'border-b border-white/5' : ''
                }`}
              >
                <div className="flex items-center gap-3">
                  {row.icon}
                  <span className="text-sm text-[#e2e8f0]/90">{row.label}</span>
                </div>
                <ToggleSwitch
                  enabled={row.state}
                  onToggle={() =>
                    setToggle(row.lsKey, !row.state, row.setter)
                  }
                />
              </div>
            ))}
          </GlassCard>
        </motion.div>

        {/* Security */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <GlassCard>
            <h3 className="text-xs uppercase tracking-wider text-[#94a3b8] mb-3">
              Security
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-[#e2e8f0]/60">Active Session</span>
                <span className="text-xs text-[#22c55e] flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Active
                </span>
              </div>
              <div className="h-px bg-white/5" />
              <div className="flex justify-between items-center">
                <span className="text-sm text-[#e2e8f0]/60">Signal Encryption</span>
                <span className="text-xs text-[#06b6d4] font-mono">AES-256</span>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* System Info */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <GlassCard>
            <h3 className="text-xs uppercase tracking-wider text-[#94a3b8] mb-3">
              System Info
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-[#e2e8f0]/60">App version</span>
                <span className="text-xs text-[#e2e8f0]/40 font-mono">
                  WAR ROOM v0.2.5
                </span>
              </div>
              <div className="h-px bg-white/5" />
              <div className="flex justify-between items-center">
                <span className="text-sm text-[#e2e8f0]/60">Stack</span>
                <span className="text-xs text-[#e2e8f0]/40 font-mono">
                  Next.js 16 + Prisma 7 + SQLite
                </span>
              </div>
              <div className="h-px bg-white/5" />
              <div className="flex justify-between items-center">
                <span className="text-sm text-[#e2e8f0]/60">Status</span>
                <span className="text-xs text-[#22c55e] flex items-center gap-1">
                  <Activity className="w-3 h-3" />
                  Operational
                </span>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Logout */}
        <motion.button
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          onClick={handleLogout}
          className="w-full bg-[#ef4444]/10 border border-[#ef4444]/20 rounded-xl p-4 flex items-center justify-center gap-2 text-[#ef4444] hover:bg-[#ef4444]/20 transition-colors active:scale-[0.98]"
        >
          <LogOut className="w-4 h-4" />
          <span className="text-sm font-medium">Terminate Session</span>
        </motion.button>
      </div>
    </WarRoomShell>
  );
}
