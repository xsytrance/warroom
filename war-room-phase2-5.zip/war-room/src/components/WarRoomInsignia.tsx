'use client';

import { motion } from 'framer-motion';

interface WarRoomInsigniaProps {
  size?: number;
  animated?: boolean;
  className?: string;
}

export function WarRoomInsignia({ size = 64, animated = true, className = '' }: WarRoomInsigniaProps) {
  return (
    <motion.div
      className={`relative inline-flex items-center justify-center ${className}`}
      style={{ width: size, height: size }}
      initial={animated ? { scale: 0.8, opacity: 0 } : false}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
    >
      {/* Outer glow ring */}
      <div
        className="absolute inset-0 rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(239,68,68,0.15) 0%, transparent 70%)',
        }}
      />

      {/* SVG Shield */}
      <svg
        width={size * 0.7}
        height={size * 0.7}
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Shield outline */}
        <path
          d="M24 4L6 12V22C6 32.5 13.5 41.5 24 44C34.5 41.5 42 32.5 42 22V12L24 4Z"
          stroke="#ef4444"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="rgba(239,68,68,0.08)"
        />

        {/* Inner shield line */}
        <path
          d="M24 8L10 14.5V22C10 30.5 15.5 37.5 24 40C32.5 37.5 38 30.5 38 22V14.5L24 8Z"
          stroke="#ef4444"
          strokeWidth="1"
          strokeOpacity="0.3"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />

        {/* Signal wave lines */}
        <path
          d="M16 22C16 22 19 19 24 19C29 19 32 22 32 22"
          stroke="#06b6d4"
          strokeWidth="1.5"
          strokeLinecap="round"
          fill="none"
        />
        <path
          d="M18 26C18 26 20.5 24 24 24C27.5 24 30 26 30 26"
          stroke="#06b6d4"
          strokeWidth="1.5"
          strokeLinecap="round"
          fill="none"
          opacity="0.6"
        />

        {/* Center dot */}
        <circle cx="24" cy="30" r="2" fill="#ef4444" />

        {/* Radar sweep arc */}
        <path
          d="M24 30L24 20"
          stroke="#ef4444"
          strokeWidth="1"
          strokeLinecap="round"
          opacity="0.4"
        />
        <path
          d="M24 30L30 25"
          stroke="#ef4444"
          strokeWidth="1"
          strokeLinecap="round"
          opacity="0.2"
        />
      </svg>

      {/* Corner accents */}
      <div className="absolute top-0 left-0 w-2 h-2 border-l border-t border-[#ef4444]/40 rounded-tl-sm" />
      <div className="absolute top-0 right-0 w-2 h-2 border-r border-t border-[#ef4444]/40 rounded-tr-sm" />
      <div className="absolute bottom-0 left-0 w-2 h-2 border-l border-b border-[#ef4444]/40 rounded-bl-sm" />
      <div className="absolute bottom-0 right-0 w-2 h-2 border-r border-b border-[#ef4444]/40 rounded-br-sm" />
    </motion.div>
  );
}
