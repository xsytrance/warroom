import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getSession } from '@/lib/auth';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const roomId = searchParams.get('roomId');

  const posts = await prisma.post.findMany({
    where: roomId ? { roomId } : undefined,
    orderBy: { createdAt: 'desc' },
    take: 50,
    include: {
      author: {
        select: { id: true, username: true, displayName: true, avatarUrl: true, roleTitle: true, status: true },
      },
      room: {
        select: { id: true, name: true, color: true, slug: true },
      },
      reactions: {
        select: { id: true, emoji: true, label: true, userId: true },
      },
      _count: {
        select: { comments: true, reactions: true },
      },
    },
  });

  return NextResponse.json({ posts });
}

export async function POST(request: Request) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized — session required' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { body: postBody, roomId, type, mediaUrl, mediaType, linkUrl } = body;

    // Validation: must have at least body OR media
    const hasBody = postBody && typeof postBody === 'string' && postBody.trim().length > 0;
    const hasMedia = mediaUrl && typeof mediaUrl === 'string' && mediaUrl.trim().length > 0;

    if (!hasBody && !hasMedia) {
      return NextResponse.json({ error: 'A message or image is required' }, { status: 400 });
    }

    if (!roomId || typeof roomId !== 'string') {
      return NextResponse.json({ error: 'Room is required' }, { status: 400 });
    }

    if (hasBody && postBody.trim().length > 2000) {
      return NextResponse.json({ error: 'Message exceeds 2000 character limit' }, { status: 400 });
    }

    // Validate mediaType if mediaUrl is provided
    if (hasMedia && mediaType) {
      const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/*'];
      if (!allowedTypes.some(t => mediaType === t || (t.endsWith('/*') && mediaType.startsWith(t.replace('/*', ''))))) {
        return NextResponse.json({ error: 'Invalid media type' }, { status: 400 });
      }
    }

    // Verify room exists
    const room = await prisma.room.findUnique({ where: { id: roomId } });
    if (!room) {
      return NextResponse.json({ error: 'Invalid room — room not found' }, { status: 400 });
    }

    // Create post
    const post = await prisma.post.create({
      data: {
        body: hasBody ? postBody.trim() : '',
        roomId,
        authorId: session.userId,
        type: type || 'human_broadcast',
        mediaUrl: hasMedia ? mediaUrl.trim() : null,
        mediaType: hasMedia ? (mediaType || 'image/*') : null,
        linkUrl: linkUrl || null,
      },
      include: {
        author: {
          select: { id: true, username: true, displayName: true, avatarUrl: true, roleTitle: true, status: true },
        },
        room: {
          select: { id: true, name: true, color: true, slug: true },
        },
        reactions: {
          select: { id: true, emoji: true, label: true, userId: true },
        },
        _count: {
          select: { comments: true, reactions: true },
        },
      },
    });

    return NextResponse.json({ post }, { status: 201 });
  } catch (error) {
    console.error('POST /api/posts error:', error);
    return NextResponse.json({ error: 'Failed to create broadcast. Please try again.' }, { status: 500 });
  }
}
