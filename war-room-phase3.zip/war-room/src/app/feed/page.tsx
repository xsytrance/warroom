'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Heart, MessageCircle, Hash, Radio, Rocket, Cpu,
  Palette, Lightbulb, Microscope, Sparkles, RefreshCw, Crosshair
} from 'lucide-react';
import { useReducedMotion } from '@/components/motion/useReducedMotion';
import { WarRoomShell } from '@/components/WarRoomShell';
import { ImageLightbox } from '@/components/media/ImageLightbox';

interface User { id: string; username: string; displayName: string; roleTitle: string; avatarUrl?: string; status?: string; }
interface Room { id: string; name: string; color: string; slug: string; }
interface Reaction { id: string; emoji: string; label: string; userId: string; }
interface Post {
  id: string; body: string; createdAt: string; type: string;
  mediaUrl?: string; mediaType?: string; linkUrl?: string;
  author: User; room: Room; reactions: Reaction[];
  _count: { comments: number; reactions: number; };
}

function relativeTime(dateStr: string) {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function renderBodyWithLinks(body: string) {
  if (!body) return null;
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const parts = body.split(urlRegex);
  const matches = body.match(urlRegex) || [];
  return (
    <>
      {parts.map((part, i) => (
        <span key={i}>
          {part}
          {matches[i] && (
            <a
              href={matches[i]}
              target="_blank" rel="noopener noreferrer"
              className="text-[#06b6d4] hover:text-[#22d3ee] hover:underline break-all"
              onClick={(e) => e.stopPropagation()}
            >
              {matches[i]}
            </a>
          )}
        </span>
      ))}
    </>
  );
}

function getRoleColor(role: string) {
  if (role.toLowerCase().includes('supreme'))
    return 'text-[#ef4444] border-[#ef4444]/30 bg-[#ef4444]/10';
  if (role.toLowerCase().includes('field'))
    return 'text-[#06b6d4] border-[#06b6d4]/30 bg-[#06b6d4]/10';
  return 'text-[#94a3b8] border-[#94a3b8]/30 bg-[#94a3b8]/10';
}

function getPostTypeIcon(type: string) {
  switch(type) {
    case 'agent_report': return <Radio className="w-3.5 h-3.5" />;
    case 'art_drop': return <Palette className="w-3.5 h-3.5" />;
    case 'build_log': return <Cpu className="w-3.5 h-3.5" />;
    case 'research_find': return <Microscope className="w-3.5 h-3.5" />;
    case 'iot_event': return <Lightbulb className="w-3.5 h-3.5" />;
    default: return <Radio className="w-3.5 h-3.5" />;
  }
}

function getPostTypeColor(type: string) {
  switch(type) {
    case 'human_broadcast': return '#ef4444';
    case 'agent_report': return '#06b6d4';
    case 'art_drop': return '#a855f7';
    case 'build_log': return '#22c55e';
    case 'research_find': return '#3b82f6';
    case 'iot_event': return '#f59e0b';
    default: return '#ef4444';
  }
}

const ROOM_ICONS: Record<string, React.ReactNode> = {
  general: <Radio className="w-3.5 h-3.5" />,
  'ai-starter-kit': <Rocket className="w-3.5 h-3.5" />,
  'agent-actions': <Cpu className="w-3.5 h-3.5" />,
  'art-studio': <Palette className="w-3.5 h-3.5" />,
  'iot-lab': <Lightbulb className="w-3.5 h-3.5" />,
  research: <Microscope className="w-3.5 h-3.5" />,
  random: <Sparkles className="w-3.5 h-3.5" />,
};

export default function FeedPage() {
  const reducedMotion = useReducedMotion();
  const [posts, setPosts] = useState<Post[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [users, setUsers] = useState<User[]>([]);

  // Lightbox state
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string>('');
  const [lightboxCaption, setLightboxCaption] = useState<string>('');

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError('');
      const [postsRes, roomsRes, usersRes] = await Promise.all([
        fetch(activeFilter ? `/api/posts?roomId=${activeFilter}` : '/api/posts'),
        fetch('/api/rooms'),
        fetch('/api/users'),
      ]);
      const postsData = await postsRes.json();
      const roomsData = await roomsRes.json();
      const usersData = await usersRes.json();
      setPosts(postsData.posts || []);
      setRooms(roomsData.rooms || []);
      setUsers(usersData.users || []);
    } catch {
      setError('Failed to load intel feed');
    } finally {
      setLoading(false);
    }
  }, [activeFilter]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const openLightbox = useCallback((imageUrl: string, caption: string) => {
    setLightboxImage(imageUrl);
    setLightboxCaption(caption);
    setLightboxOpen(true);
  }, []);

  const filteredPosts = posts;

  return (
    <WarRoomShell showNav={true} showBackground={true}>
      {/* Lightbox */}
      <ImageLightbox
        src={lightboxImage}
        alt="Broadcast media"
        caption={lightboxCaption}
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
      />

      {/* Header */}
      <div className="sticky top-0 z-20 bg-[#0a0a0f]/90 backdrop-blur-md border-b border-[#ef4444]/20 safe-top">
        <div className="max-w-2xl mx-auto px-4 py-3">
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2 rounded-lg bg-[#ef4444]/10 border border-[#ef4444]/20">
              <Crosshair className="w-4 h-4 text-[#ef4444]" />
            </div>
            <h1 className="text-sm font-bold tracking-[0.2em] uppercase text-[#ef4444]">
              WAR ROOM STATUS
            </h1>
            <div className="ml-auto">
              <button
                onClick={fetchData}
                className="p-2 rounded-lg bg-white/5 border border-white/10 text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-white/10 transition-all active:scale-95"
                aria-label="Refresh feed"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Active Users Bar */}
          <div className="flex items-center gap-2 mb-3 overflow-x-auto scrollbar-hide">
            {users.length > 0 ? (
              users.map((u) => (
                <div
                  key={u.id}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-white/10 bg-white/5 shrink-0"
                >
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{
                      backgroundColor: u.status?.toLowerCase().includes('building') ? '#22c55e' : '#22c55e',
                      boxShadow: '0 0 6px #22c55e',
                    }}
                  />
                  <span className="text-xs text-[#e2e8f0] font-medium whitespace-nowrap">{u.displayName}</span>
                </div>
              ))
            ) : (
              [
                { name: 'xsytrance', color: '#ef4444' },
                { name: 'Juan', color: '#06b6d4' },
                { name: 'VG God', color: '#94a3b8' },
                { name: 'Picasso', color: '#94a3b8' },
                { name: 'Ultron', color: '#94a3b8' },
              ].map((agent) => (
                <div
                  key={agent.name}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-white/10 bg-white/5 shrink-0"
                >
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: agent.color, boxShadow: `0 0 6px ${agent.color}` }}
                  />
                  <span className="text-xs text-[#e2e8f0] font-medium whitespace-nowrap">{agent.name}</span>
                </div>
              ))
            )}
          </div>

          {/* Room Filters */}
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
            <button
              onClick={() => setActiveFilter(null)}
              className={`shrink-0 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all min-h-[44px] border ${
                !activeFilter
                  ? 'bg-[#06b6d4]/15 text-[#06b6d4] border-[#06b6d4]/30 shadow-[0_0_10px_rgba(6,182,212,0.15)]'
                  : 'bg-white/5 text-[#94a3b8] border-white/10 hover:bg-white/10'
              }`}
            >
              ALL
            </button>
            {rooms.map((room) => (
              <button
                key={room.id}
                onClick={() => setActiveFilter(activeFilter === room.id ? null : room.id)}
                className={`shrink-0 flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all min-h-[44px] border ${
                  activeFilter === room.id
                    ? ''
                    : 'bg-white/5 text-[#94a3b8] border-white/10 hover:bg-white/10'
                }`}
                style={
                  activeFilter === room.id
                    ? { backgroundColor: `${room.color}15`, borderColor: `${room.color}40`, color: room.color, boxShadow: `0 0 10px ${room.color}20` }
                    : undefined
                }
              >
                {ROOM_ICONS[room.slug] || <Hash className="w-3.5 h-3.5" />}
                <span className="whitespace-nowrap">{room.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Feed Content */}
      <div className="max-w-2xl mx-auto px-4 py-5 pb-32 space-y-5">
        {loading && (
          <div className="flex items-center gap-3 justify-center py-20">
            <div className="w-6 h-6 border-2 border-[#06b6d4]/30 border-t-[#06b6d4] rounded-full animate-spin" />
            <span className="text-sm text-[#475569] tracking-wider uppercase">Establishing Uplink...</span>
          </div>
        )}

        {error && !loading && (
          <div className="p-4 rounded-xl border border-[#ef4444]/30 bg-[#ef4444]/10 text-center">
            <p className="text-sm text-[#ef4444]">{error}</p>
            <button onClick={fetchData} className="mt-2 text-xs text-[#06b6d4] hover:text-[#22d3ee] tracking-wider uppercase">
              Retry Connection
            </button>
          </div>
        )}

        {!loading && !error && filteredPosts.length === 0 && (
          <div className="text-center py-20">
            <div className="inline-flex p-4 rounded-2xl bg-[#12121a] border border-white/10 mb-4">
              <Radio className="w-8 h-8 text-[#475569]" />
            </div>
            <h3 className="text-sm font-bold tracking-wider uppercase text-[#475569] mb-2">No Signals Detected</h3>
            <p className="text-xs text-[#475569] max-w-[200px] mx-auto">
              {activeFilter
                ? 'No broadcasts in this channel yet. Select ALL to see everything.'
                : 'Be the first to broadcast intel to the War Room.'}
            </p>
          </div>
        )}

        {!loading && filteredPosts.map((post: Post, index: number) => (
          <div
            key={post.id}
            className="rounded-xl border border-white/10 bg-[#12121a]/90 backdrop-blur-sm p-4 transition-all hover:bg-[#1a1a2e]/90 hover:border-white/15 hover:shadow-[0_0_20px_rgba(6,182,212,0.06)]"
            style={{
              animation: reducedMotion ? 'none' : `cardIn 0.4s ease-out ${index * 0.06}s both`,
            }}
          >
            {/* Card Header */}
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold border ${getRoleColor(post.author.roleTitle)}`}>
                  {(post.author.displayName || post.author.username)?.[0]?.toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-[#e2e8f0]">{post.author.displayName || post.author.username}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded border ${getRoleColor(post.author.roleTitle)}`}>
                      {post.author.roleTitle}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span
                      className="text-[11px] flex items-center gap-1 px-1.5 py-0.5 rounded-full font-medium"
                      style={{
                        backgroundColor: `${post.room.color}15`,
                        color: post.room.color,
                        border: `1px solid ${post.room.color}30`,
                      }}
                    >
                      {ROOM_ICONS[post.room.slug] || <Hash className="w-3 h-3" />}
                      {post.room.name}
                    </span>
                    <span className="text-[11px] text-[#475569]">{relativeTime(post.createdAt)}</span>
                  </div>
                </div>
              </div>

              {/* Post type badge */}
              <span
                className="flex items-center gap-1 text-[10px] px-2 py-1 rounded-full border font-medium uppercase tracking-wider"
                style={{
                  color: getPostTypeColor(post.type),
                  backgroundColor: `${getPostTypeColor(post.type)}10`,
                  borderColor: `${getPostTypeColor(post.type)}25`,
                }}
              >
                {getPostTypeIcon(post.type)}
                {post.type === 'human_broadcast' ? 'BROADCAST' : post.type.replace(/_/g, ' ').toUpperCase()}
              </span>
            </div>

            {/* Post Body */}
            {post.body && post.body.trim().length > 0 && (
              <div className="mb-3 text-sm text-[#e2e8f0] leading-relaxed whitespace-pre-wrap break-words">
                {renderBodyWithLinks(post.body)}
              </div>
            )}

            {/* Post Image */}
            {post.mediaUrl && (
              <div
                className="mb-3 rounded-lg border border-white/10 overflow-hidden cursor-pointer group relative"
                onClick={() => openLightbox(post.mediaUrl!, `${post.author.displayName} · ${post.room.name} · ${relativeTime(post.createdAt)}`)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === 'Enter' && openLightbox(post.mediaUrl!, `${post.author.displayName} · ${post.room.name}`)}
                aria-label="Open image fullscreen"
              >
                <img
                  src={post.mediaUrl}
                  alt="Broadcast media"
                  className="w-full max-h-80 object-cover group-hover:scale-[1.02] transition-transform duration-300"
                  loading="lazy"
                />
                {/* Hover overlay with expand icon */}
                <div className="absolute inset-0 bg-[#0a0a0f]/0 group-hover:bg-[#0a0a0f]/30 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                  <div className="p-2 rounded-lg bg-[#0a0a0f]/60 border border-white/20">
                    <Crosshair className="w-5 h-5 text-[#e2e8f0]" />
                  </div>
                </div>
                {/* Corner accents */}
                <div className="absolute top-2 left-2 w-3 h-3 border-l border-t border-[#06b6d4]/40 rounded-tl-sm" />
                <div className="absolute top-2 right-2 w-3 h-3 border-r border-t border-[#06b6d4]/40 rounded-tr-sm" />
                <div className="absolute bottom-2 left-2 w-3 h-3 border-l border-b border-[#06b6d4]/40 rounded-bl-sm" />
                <div className="absolute bottom-2 right-2 w-3 h-3 border-r border-b border-[#06b6d4]/40 rounded-br-sm" />
              </div>
            )}

            {/* Link Card */}
            {post.linkUrl && !post.mediaUrl && (
              <a
                href={post.linkUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mb-3 block p-3 rounded-lg border border-[#06b6d4]/20 bg-[#06b6d4]/5 hover:bg-[#06b6d4]/10 transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                <span className="text-xs text-[#06b6d4] font-medium break-all">{post.linkUrl}</span>
              </a>
            )}

            {/* Reactions & Comments */}
            <div className="flex items-center gap-4 pt-3 border-t border-white/5">
              <div className="flex items-center gap-1.5">
                <Heart className="w-3.5 h-3.5 text-[#475569]" />
                {post.reactions.length > 0 ? (
                  <div className="flex items-center gap-1">
                    {post.reactions.slice(0, 5).map((r, i) => (
                      <span key={i} className="text-sm">{r.emoji}</span>
                    ))}
                    {post.reactions.length > 5 && (
                      <span className="text-[10px] text-[#475569]">+{post.reactions.length - 5}</span>
                    )}
                  </div>
                ) : (
                  <span className="text-xs text-[#475569]">No reactions</span>
                )}
              </div>

              {post._count.comments > 0 && (
                <div className="flex items-center gap-1.5">
                  <MessageCircle className="w-3.5 h-3.5 text-[#475569]" />
                  <span className="text-xs text-[#475569]">{post._count.comments} replies</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <style jsx>{`
        @keyframes cardIn {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </WarRoomShell>
  );
}
