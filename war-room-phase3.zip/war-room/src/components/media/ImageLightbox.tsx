'use client';

import { useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Crosshair } from 'lucide-react';
import { useReducedMotion } from '@/components/motion/useReducedMotion';

interface ImageLightboxProps {
  src: string;
  alt?: string;
  caption?: string;
  isOpen: boolean;
  onClose: () => void;
}

export function ImageLightbox({ src, alt = 'Image', caption, isOpen, onClose }: ImageLightboxProps) {
  const reducedMotion = useReducedMotion();

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    },
    [onClose]
  );

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, handleKeyDown]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={reducedMotion ? { opacity: 0 } : { opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: reducedMotion ? 0.1 : 0.25 }}
          className="fixed inset-0 z-[70] flex items-center justify-center"
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-label="Image lightbox"
        >
          {/* Dark tactical overlay */}
          <div className="absolute inset-0 bg-[#0a0a0f]/95 backdrop-blur-sm" />

          {/* Corner accents */}
          <div className="absolute top-4 left-4 w-6 h-6 border-l-2 border-t-2 border-[#ef4444]/40 rounded-tl" />
          <div className="absolute top-4 right-4 w-6 h-6 border-r-2 border-t-2 border-[#ef4444]/40 rounded-tr" />
          <div className="absolute bottom-4 left-4 w-6 h-6 border-l-2 border-b-2 border-[#ef4444]/40 rounded-bl" />
          <div className="absolute bottom-4 right-4 w-6 h-6 border-r-2 border-b-2 border-[#ef4444]/40 rounded-br" />

          {/* Close button */}
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ delay: reducedMotion ? 0 : 0.1, duration: 0.2 }}
            onClick={onClose}
            className="absolute top-4 right-4 z-10 p-3 rounded-xl bg-white/5 border border-white/10 text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-white/10 transition-all active:scale-95"
            aria-label="Close lightbox"
          >
            <X className="w-5 h-5" />
          </motion.button>

          {/* Target reticle center indicator */}
          <div className="absolute top-4 left-4 z-10">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10">
              <Crosshair className="w-3.5 h-3.5 text-[#06b6d4]" />
              <span className="text-[10px] font-medium uppercase tracking-wider text-[#475569]">
                Fullscreen View
              </span>
            </div>
          </div>

          {/* Image container */}
          <motion.div
            initial={reducedMotion ? {} : { scale: 0.85, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={reducedMotion ? {} : { scale: 0.9, opacity: 0 }}
            transition={{ duration: reducedMotion ? 0.1 : 0.3, ease: 'easeOut' }}
            className="relative z-10 max-w-[95vw] max-h-[85vh] mx-4"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={src}
              alt={alt}
              className="max-w-full max-h-[85vh] rounded-lg object-contain border border-white/10"
            />
            {/* Subtle glow around image */}
            <div
              className="absolute -inset-4 rounded-2xl pointer-events-none"
              style={{
                background: 'radial-gradient(circle, rgba(6,182,212,0.08) 0%, transparent 70%)',
              }}
            />
          </motion.div>

          {/* Caption */}
          {caption && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: reducedMotion ? 0 : 0.2, duration: 0.2 }}
              className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
            >
              <span className="px-4 py-2 rounded-lg bg-[#12121a]/80 border border-white/10 text-xs text-[#94a3b8] backdrop-blur-sm">
                {caption}
              </span>
            </motion.div>
          )}

          {/* Tap hint */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: reducedMotion ? 0 : 0.5, duration: 0.3 }}
            className="absolute bottom-20 left-1/2 -translate-x-1/2 z-10"
          >
            <span className="text-[10px] text-[#475569] tracking-wider uppercase">
              Tap anywhere to close
            </span>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
