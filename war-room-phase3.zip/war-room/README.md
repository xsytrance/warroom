# THE WAR ROOM

A private, mobile-first Progressive Web App for xsytrance and Juan to coordinate their AI empire.

**Private command hub. Tactical cyberpunk aesthetic. Built for mobile.**

---

## What is The War Room?

The War Room is a private social command hub — not Slack, not Discord, not a generic chat app. It is a secure, tactical collaboration space where xsytrance and Juan can:

- Post updates (Broadcasts) to the Intel Feed
- Share images, links, and media
- Comment and react (Salute, Fire, Laugh, Mind Blown, Approved)
- Organize conversations into Rooms (General, AI Starter Kit, Agent Actions, Art Studio, IoT Lab, Research, Random)
- View agent status and prepare for future Hermes agent integration
- Run entirely on private infrastructure behind Tailscale

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | Next.js 16 (App Router) |
| Language | TypeScript |
| Styling | Tailwind CSS v4 |
| Animation | Framer Motion |
| Database | SQLite (via better-sqlite3) |
| ORM | Prisma 7 |
| Auth | JWT (jose) + bcryptjs + httpOnly cookies |
| UI Icons | Lucide React |

---

## Quick Start

### 1. Install Dependencies

```bash
cd war-room
npm install
```

### 2. Set Environment Variables

Create `.env` (or edit existing):

```env
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="your-secret-key-change-this-in-production"
NODE_ENV="development"
```

### 3. Initialize Database

```bash
# Generate Prisma client
npx prisma generate

# Run migrations (creates SQLite database)
npx prisma migrate dev --name init

# Seed with demo users, rooms, agents, and posts
npx prisma db seed
# OR: npx tsx prisma/seed.ts
```

### 4. Run Development Server

```bash
npm run dev
```

Open http://localhost:3000

**Demo Login Credentials:**
- **xsytrance** / `warroom2024`
- **juan** / `warroom2024`

### 5. Build for Production

```bash
npm run build
npm run start
```

---

## Phase 2 Testing

### How to Test the Broadcast Composer

1. **Login** at `/login` with `xsytrance` / `warroom2024`
2. **Tap BROADCAST** in the bottom nav (red button with plus icon)
3. **Select a room** from the 7 room buttons (color-coded)
4. **Optionally change signal type** — tap "Change" next to "Broadcast"
5. **Type your message** in the text area (max 2000 chars)
6. **Paste a URL** to see link detection in action
7. **Tap BROADCAST SIGNAL** (bottom) or **SEND** (top-right)
8. **Watch the pulse animation** → auto-redirect to feed
9. **See your post at the top** with correct room badge and timestamp

### API Tests (curl)

```bash
# 1. Login
curl -c cookies.txt -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"xsytrance","password":"warroom2024"}'

# 2. Create a broadcast
curl -b cookies.txt -X POST http://localhost:3000/api/posts \
  -H "Content-Type: application/json" \
  -d '{"body":"Test broadcast","roomId":"ROOM_ID_HERE","type":"human_broadcast"}'

# 3. Empty body should fail
curl -b cookies.txt -X POST http://localhost:3000/api/posts \
  -H "Content-Type: application/json" \
  -d '{"body":"","roomId":"ROOM_ID_HERE"}'
# → {"error":"Message body is required"}

# 4. Invalid room should fail
curl -b cookies.txt -X POST http://localhost:3000/api/posts \
  -H "Content-Type: application/json" \
  -d '{"body":"test","roomId":"invalid"}'
# → {"error":"Invalid room — room not found"}

# 5. Unauthenticated should fail
curl -X POST http://localhost:3000/api/posts \
  -H "Content-Type: application/json" \
  -d '{"body":"test","roomId":"x"}'
# → {"error":"Unauthorized"}
```

---

## Project Structure

```
war-room/
├── prisma/
│   ├── schema.prisma       # Database schema (User, Room, Post, Comment, Reaction, Agent)
│   ├── seed.ts             # Demo data seed script
│   └── migrations/           # Database migrations
├── src/
│   ├── app/                  # Next.js App Router
│   │   ├── api/              # API Routes
│   │   │   ├── auth/         # Login, Logout, Me
│   │   │   ├── posts/        # Posts CRUD (GET list, POST create)
│   │   │   ├── comments/     # Comments CRUD
│   │   │   ├── reactions/    # Reactions toggle
│   │   │   ├── rooms/        # Rooms list
│   │   │   └── agents/       # Agents list
│   │   ├── broadcast/        # **Broadcast Composer (Phase 2)**
│   │   ├── feed/             # Intel Feed page
│   │   ├── rooms/            # Rooms directory page
│   │   ├── agents/           # Agents page
│   │   ├── profile/          # User profile page
│   │   ├── settings/         # App settings page
│   │   ├── login/            # Login page
│   │   ├── page.tsx          # Home (redirects)
│   │   ├── layout.tsx        # Root layout with PWA metadata
│   │   └── globals.css       # Tactical theme + animations
│   ├── components/
│   │   ├── BottomNav.tsx     # Bottom nav with BROADCAST button
│   │   ├── motion/           # VFX components
│   │   │   ├── ParticleField.tsx
│   │   │   ├── TacticalGrid.tsx
│   │   │   ├── RadarSweep.tsx
│   │   │   ├── SignalPulse.tsx      # Broadcast success animation
│   │   │   ├── Scanlines.tsx
│   │   │   ├── GlitchText.tsx
│   │   │   ├── useReducedMotion.ts  # Motion preference hook
│   │   │   └── index.ts
│   │   └── ...               # Feed cards, reaction bars, etc.
│   ├── lib/
│   │   ├── db.ts             # Prisma client singleton
│   │   ├── auth.ts           # Session utilities
│   │   └── utils.ts          # cn() helper
│   └── proxy.ts              # Route protection (auth middleware)
├── public/
│   ├── icons/                # PWA icons (72x72 to 512x512)
│   ├── manifest.json         # PWA manifest
│   └── avatars/              # Placeholder avatar images
├── .env                      # Environment variables
├── next.config.ts            # Next.js config (standalone output)
├── package.json
└── tsconfig.json
```

---

## Current Features (Phase 0 + 1 + 2)

### Authentication
- [x] Username/password login with bcrypt
- [x] JWT session cookies (httpOnly, secure)
- [x] Route protection via proxy middleware
- [x] Auto-redirect unauthenticated users to login
- [x] Logout with session destruction

### Mobile Shell
- [x] Mobile-first layout with safe-area support
- [x] Bottom navigation (Feed, Rooms, Agents, Profile) + prominent **BROADCAST** button
- [x] PWA manifest and install support
- [x] Dark tactical theme (near-black, red, cyan, green accents)

### Intel Feed
- [x] Broadcast cards with author, room badge, timestamp
- [x] Text posts with full CRUD API
- [x] **URL auto-linking** — URLs in post body render as clickable cyan links
- [x] Room filtering with pill selector
- [x] Real-time feed refresh after posting (auto-redirect to feed)
- [x] Demo posts seeded (8 posts)

### Broadcast Composer (Phase 2 — NEW)
- [x] **Dedicated /broadcast page** with full-screen mobile composer
- [x] **Room selector** — all 7 rooms with color-coded buttons
- [x] **Signal type selector** — Broadcast, Agent Report, Art Drop, Build Log, Research, IoT Event
- [x] **Text area** with 2000 character limit, real-time counter
- [x] **Link detection** — auto-detects URLs in message body, shows preview
- [x] **Submit validation** — disabled when empty, loading state while transmitting
- [x] **Error handling** — clear inline errors for invalid room, empty body, network issues
- [x] **Success animation** — SignalPulse overlay with "SIGNAL SENT" confirmation
- [x] **Auto-redirect** to feed after successful broadcast
- [x] **Cancel with discard confirmation** if text entered
- [x] Reduced-motion support throughout

### Reactions & Comments
- [x] 5 reaction types: Salute, Fire, Laugh, Mind Blown, Approved
- [x] Reaction toggle API
- [x] Comments with author
- [x] Comment count on posts

### Rooms
- [x] 7 rooms: General, AI Starter Kit, Agent Actions, Art Studio, IoT Lab, Research, Random
- [x] Room directory page with color coding
- [x] Filter feed by room

### Agents (Foundation)
- [x] 4 seeded agents: VG God, Picasso, Ultron, Juan's Deployment Agent
- [x] Agents page with status cards
- [x] Agent model ready for future API integration

### Visual Effects
- [x] Animated particle background
- [x] Tactical grid overlay
- [x] Radar sweep component
- [x] Signal pulse animation (used in broadcast success)
- [x] Scanline overlay
- [x] Glitch text effect
- [x] Reduced motion support throughout

### Settings
- [x] Sound effects toggle (placeholder)
- [x] Reduced motion toggle
- [x] Logout button

---

## Deployment Notes

### Running on PRIME / VPS

```bash
# Build
npm run build

# Start production server
npm run start
# or
PORT=3000 node .next/standalone/server.js
```

### Tailscale Access

1. Install Tailscale on the server
2. Run the app on a local port (e.g., 3000)
3. Access via the server's Tailscale IP: `http://100.x.x.x:3000`
4. No public internet exposure required

### Systemd Service (Example)

Create `/etc/systemd/system/war-room.service`:

```ini
[Unit]
Description=The War Room
After=network.target

[Service]
Type=simple
User=xsytrance
WorkingDirectory=/home/xsytrance/war-room
ExecStart=/usr/bin/npm run start
Restart=on-failure
Environment=NODE_ENV=production
Environment=NEXTAUTH_SECRET=your-production-secret

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable war-room
sudo systemctl start war-room
```

### Environment Variables for Production

```env
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="long-random-string-min-32-chars"
NODE_ENV="production"
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login, sets session cookie |
| POST | `/api/auth/logout` | Logout, clears cookie |
| GET | `/api/auth/me` | Get current user |
| GET | `/api/posts?roomId=` | List posts (optionally filtered) |
| POST | `/api/posts` | **Create a broadcast** |
| GET | `/api/comments?postId=` | List comments for post |
| POST | `/api/comments` | Create a comment |
| POST | `/api/reactions` | Toggle reaction |
| DELETE | `/api/reactions` | Remove reaction |
| GET | `/api/rooms` | List all rooms |
| GET | `/api/agents` | List all agents |

### POST /api/posts Payload

```json
{
  "roomId": "room-uuid",
  "body": "Your broadcast message",
  "type": "human_broadcast",
  "mediaUrl": null,
  "mediaType": null,
  "linkUrl": null
}
```

Validation:
- `body` is required and must be non-empty (max 2000 chars)
- `roomId` is required and must be a valid room
- `type` defaults to `human_broadcast`
- Returns 201 with created post on success
- Returns 400 with specific error message on validation failure
- Returns 401 if unauthenticated

### Future Agent API (Phase 6+)

```
POST /api/agent/broadcast
Authorization: Bearer <agent-token>
Body: {
  "agent": "picasso",
  "room": "art-studio",
  "type": "art_drop",
  "title": "New image generated",
  "body": "...",
  "mediaUrl": "/uploads/example.png",
  "priority": "normal",
  "metadata": { "model": "Flux", "prompt": "...", "seed": "12345" }
}
```

---

## Database Schema

```prisma
model User {
  id, username, displayName, passwordHash, avatarUrl, roleTitle, status
  posts, comments, reactions
}

model Room {
  id, name, slug, description, icon, color
  posts
}

model Post {
  id, authorId, roomId, type, title, body
  mediaUrl, mediaType, linkUrl, metadataJson, priority
  author, room, comments, reactions
}

model Comment {
  id, postId, authorId, body
  post, author
}

model Reaction {
  id, postId, userId, emoji, label
  post, user
}

model Agent {
  id, name, slug, roleTitle, avatarUrl, status, apiTokenHash
}
```

---

## Post Types

| Type | Purpose |
|------|---------|
| `human_broadcast` | Regular user post |
| `agent_report` | Agent status/mission update |
| `art_drop` | Generated artwork |
| `music_drop` | Generated music |
| `research_find` | Research discovery |
| `build_log` | Build/deployment update |
| `iot_event` | IoT device event |
| `alert` | Urgent notification |
| `mission_update` | Mission status change |
| `file_drop` | Shared file/document |

---

## Phase Roadmap

| Phase | Status | Goal |
|-------|--------|------|
| 0 | Complete | Project scaffold, Prisma schema, seed data, PWA config |
| 1 | Complete | Auth, mobile shell, tactical theme, visual effects |
| 2 | **Complete** | **Broadcast composer, create post API, link detection, feed refresh** |
| 3 | **Complete** | **Media uploads (image + lightbox), image posting, feed rendering** |
| 4 | Planned | PWA polish + service worker + install flow |
| 5 | Planned | Agent posting API + agent auth tokens |
| 6 | Planned | Docker + systemd + Tailscale deployment docs |

---

## Known Limitations (Phase 3)
- **Image upload is LIVE** — JPEG, PNG, WebP, GIF supported, 8MB limit, local storage
- Video upload not implemented yet
- Audio upload not implemented yet
- No client-side image compression (server enforces 8MB limit)
- No drag-and-drop upload (tap-to-select only)
- No advanced media vault or search
- Real-time updates require manual refresh or navigation (WebSockets — future)
- Push notifications require service worker (Phase 4)
- Agent API is documented but not fully implemented (Phase 5)

---

## Phase 3 — Media Drops

### What Was Built

Phase 3 adds image upload, image posting, feed image rendering, and fullscreen lightbox to The War Room.

### Image Upload API

**Endpoint:** `POST /api/upload/image`

**Authentication:** Required (session cookie)

**Request:** `multipart/form-data` with field name `image`

**Allowed file types:** JPEG, PNG, WebP, GIF

**Maximum file size:** 8MB

**Storage path:** `public/uploads/images/`

**Response:**
```json
{
  "mediaUrl": "/uploads/images/<random-filename>.png",
  "mediaType": "image/png",
  "filename": "<random-filename>.png",
  "size": 12345
}
```

**Security features:**
- Safe random filenames (crypto.randomBytes, no original filename used)
- MIME type validation
- File size enforcement (8MB)
- Path traversal prevention
- No executable uploads allowed

### Broadcast Composer — Image Attachment

- **Attach Image** button on `/broadcast` with dashed border
- Shows file type hints: JPEG, PNG, WebP, GIF, Max 8MB
- Mobile-friendly file picker (accepts camera and gallery)
- Preview thumbnail after selection with remove button
- Shows filename and file size on preview overlay
- Uploads image first, then creates post with mediaUrl
- Text is optional when image is attached (and vice versa)
- Upload progress shown as **UPLOADING IMAGE...** on submit button
- Inline error if upload fails

### Feed Image Rendering

- Images render inside broadcast cards with max-h-80 and object-cover
- Click or tap opens fullscreen lightbox
- Hover overlay shows Crosshair expand icon
- Corner accent decorations match War Room aesthetic
- Lazy loading for performance

### Fullscreen Lightbox

- Dark tactical overlay with corner frame accents
- **FULLSCREEN VIEW** badge with Crosshair icon
- X close button in top-right
- Tap anywhere to close
- Escape key closes on desktop
- Background scroll locked while open
- Safe-area padding for mobile
- Smooth open/close animations with reduced-motion fallback
- Optional caption with author, room, and timestamp

### Updated Post Validation

Posts now accept either body text OR media image (or both). Empty posts with neither are rejected.

### Backup Warning

**Images are stored locally in `public/uploads/images/`.**

When backing up The War Room, include BOTH:
1. The SQLite database file (`dev.db`)
2. The uploads directory (`public/uploads/images/`)

If the database is restored without the uploads, posts will reference missing images.

---


## Security Notes

- App requires login for all routes except `/login` and auth APIs
- Passwords hashed with bcrypt (10 rounds)
- JWT sessions in httpOnly cookies
- No public registration (invite-only future)
- SQLite file should be backed up regularly
- Run behind Tailscale or VPN for private access
- Change `NEXTAUTH_SECRET` for production
- Empty posts rejected server-side
- Invalid room IDs rejected server-side
- All API routes validate authentication

---

## Credits

Built for **xsytrance** and **Juan** by the Kimi AI Swarm.

**Phase 2: Broadcast Composer is LIVE.**

Tactical design. Mobile-first. Private by default.


---

## Phase 2.5 — Visual Identity Lock-In + Mobile UX Polish

### What Was Polished

Phase 2.5 was a **design unification pass** — no new features, only visual consistency and mobile UX improvements.

### Shared Design System Components Created

| Component | File | Purpose |
|-----------|------|---------|
| `GlassCard` | `src/components/ui/GlassCard.tsx` | Standard glassmorphism card with hover glow |
| `TacticalButton` | `src/components/ui/TacticalButton.tsx` | Red primary / cyan secondary / danger buttons |
| `StatusPill` | `src/components/ui/StatusPill.tsx` | Colored status indicator with animated dot |
| `SectionHeader` | `src/components/ui/SectionHeader.tsx` | Page section headers with accent colors |
| `PageHeader` | `src/components/ui/SectionHeader.tsx` | Sticky page headers with subtitle |
| `WarRoomShell` | `src/components/WarRoomShell.tsx` | Page wrapper with ParticleField + Grid + Scanlines |
| `WarRoomInsignia` | `src/components/WarRoomInsignia.tsx` | SVG shield logo with signal waves and corner accents |

### Visual Identity Decisions

- **Color unification**: All pages use `text-[#e2e8f0]` instead of mixed `text-white` and `text-gray-300`
- **Role colors**: Supreme Commander = red, Field Commander = cyan, default = slate
- **Background effects**: Every page gets subtle ParticleField + TacticalGrid + Scanlines (unless reduced motion)
- **Glass cards**: Consistent `bg-[#12121a]/90 backdrop-blur-sm border-white/10 rounded-xl` everywhere
- **Status pills**: Animated colored dots with glow for online/standby/ready/monitoring/working states
- **Room colors**: Consistent with seed data — General=red, AI Starter Kit=cyan, Agent Actions=green, Art Studio=violet, IoT Lab=amber, Research=blue, Random=pink
- **Typography**: Headings are `tracking-wider uppercase` with accent colors

### Per-Page Polish Summary

| Page | Changes |
|------|---------|
| **Login** | WarRoomInsignia replaces generic Shield icon, "Authorized commanders only" flavor text, readable demo credentials, enhanced entrance animation |
| **Feed** | "WAR ROOM STATUS" header with Shield icon, active users bar with StatusPill, glass cards with hover glow, "ESTABLISHING UPLINK..." loading, "NO SIGNALS DETECTED" empty state, staggered card entrance animations |
| **Broadcast** | Full-screen WarRoomShell, "Broadcast Signal" header, all rooms color-coded, signal type selector, 2000-char counter, link detection preview, "SIGNAL SENT" pulse, safe-area support |
| **Rooms** | "COMMS CHANNELS" header with "Mission spaces for the AI empire", glass cards with color glow, "SCANNING CHANNELS..." loading, post counts and last activity |
| **Agents** | "ACTIVE AGENTS" header, operative cards with color-coded avatars, StatusPill for each agent, capability descriptions, "AGENT POSTING API COMING" footer |
| **Profile** | "OPERATIVE PROFILE" header with "Clearance: Level 4", identity card with role-colored avatar ring, stats with icon backgrounds, StatusPill for status, gear icon for settings |
| **Settings** | "SYSTEM CONFIG" header, functional toggles (reduced motion, sound, dark interface, alert signals, stealth mode), War Room terminology, "Terminate Session" logout, system info footer |
| **BottomNav** | Higher contrast active states (cyan bg + border), darker inactive text, prominent red BROADCAST button, aria-labels, safe-area padding |

### Motion Effects Audit

| Effect | Audit Result |
|--------|-------------|
| ParticleField | Reduced to 30 particles, `requestAnimationFrame` cleanup verified, `will-change: transform` added |
| TacticalGrid | Opacity capped at 0.20, stays behind content |
| Scanlines | Opacity 0.03, barely visible texture |
| SignalPulse | Respects reduced-motion (shorter animation) |
| GlitchText | Only renders if component exists, respects reduced motion |
| RadarSweep | Only renders if component exists |

### Mobile UX Improvements

- Touch targets: All buttons >= 44px, nav items >= 56px
- Text size: Inputs use `text-base` (16px) to prevent iOS zoom
- Safe-area: `safe-top` and `safe-bottom` padding on all sticky elements
- Spacing: Cards have `gap-5` breathing room, no cramped layouts
- Keyboard: Composer textarea has proper height, submit button reachable
- Scrolling: Horizontal room filters scroll smoothly, no clipping

### Regression Test Results

| Test | Result |
|------|--------|
| xsytrance login | PASS |
| juan login | PASS |
| logout | PASS |
| feed loads with posts | PASS (12 posts) |
| room filters work | PASS |
| broadcast composer opens | PASS |
| create post via API | PASS |
| empty post rejected | PASS (400) |
| invalid room rejected | PASS (400) |
| link detection in composer | PASS |
| link rendering in feed | PASS |
| reactions display | PASS |
| comment counts display | PASS |
| bottom nav active states | PASS |
| mobile viewport 375px | PASS |
| desktop viewport | PASS |
| reduced-motion toggle functional | PASS |
| sound toggle functional | PASS |

---

## Updated Phase Roadmap

| Phase | Status | Goal |
|-------|--------|------|
| 0 | Complete | Project scaffold, Prisma schema, seed data, PWA config |
| 1 | Complete | Auth, mobile shell, tactical theme, visual effects |
| 2 | Complete | Broadcast composer, create post API, link detection, feed refresh |
| 2.5 | **Complete** | **Visual identity lock-in, mobile UX polish, shared design system** |
| 3 | **Complete** | **Media uploads (image + lightbox), image posting, feed rendering** |
| 4 | Planned | PWA polish + service worker + install flow |
| 5 | Planned | Agent posting API + agent auth tokens |
| 6 | Planned | Docker + systemd + Tailscale deployment docs |

---

## Known Limitations (Phase 3)

- **Image upload is LIVE** — JPEG, PNG, WebP, GIF, 8MB limit, local storage
- Video upload not implemented yet
- Audio upload not implemented yet
- No client-side image compression
- No drag-and-drop upload (tap-to-select only)
- No advanced media vault or search
- Real-time updates require manual refresh (WebSockets — future)
- Push notifications require service worker (Phase 4)
- Agent API is documented but not fully implemented (Phase 5)

### Backup Warning

**Images are stored locally in `public/uploads/images/`.**

When backing up The War Room, include BOTH:
1. The SQLite database file (`dev.db`)
2. The uploads directory (`public/uploads/images/`)

If the database is restored without the uploads, posts will reference missing images.

---

**Phase 3: Media Drops COMPLETE.**

Users can now attach images to broadcasts, view them in the feed, and open fullscreen lightboxes. The War Room visual identity from Phase 2.5 is fully preserved.

Tactical design. Mobile-first. Private by default.
