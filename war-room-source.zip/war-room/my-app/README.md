# THE WAR ROOM

A private, mobile-first Progressive Web App for xsytrance and Juan to coordinate their AI empire.

**Private command hub. Tactical cyberpunk aesthetic. Built for mobile.**

---

## What is The War Room?

The War Room is a private social command hub — not Slack, not Discord, not a generic chat app. It is a secure, tactical collaboration space where xsytrance and Juan can:

- Post updates (Broadcasts) to the Intel Feed
- Share images, links, and media
- Comment and react (Salute, Fire, Laugh, Mind Blown, Approved)
- Organize conversations into Rooms (General, AI Starter Kit, Agent Actions, Art Studio, IoT Lab, Research, Random)
- View agent status and prepare for future Hermes agent integration
- Run entirely on private infrastructure behind Tailscale

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | Next.js 16 (App Router) |
| Language | TypeScript |
| Styling | Tailwind CSS v4 |
| Animation | Framer Motion |
| Database | SQLite (via better-sqlite3) |
| ORM | Prisma 7 |
| Auth | JWT (jose) + bcryptjs + httpOnly cookies |
| UI Icons | Lucide React |

---

## Quick Start

### 1. Install Dependencies

```bash
cd war-room
npm install
```

### 2. Set Environment Variables

Create `.env` (or edit existing):

```env
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="your-secret-key-change-this-in-production"
NODE_ENV="development"
```

### 3. Initialize Database

```bash
# Generate Prisma client
npx prisma generate

# Run migrations (creates SQLite database)
npx prisma migrate dev --name init

# Seed with demo users, rooms, agents, and posts
npx prisma db seed
# OR: npx tsx prisma/seed.ts
```

### 4. Run Development Server

```bash
npm run dev
```

Open http://localhost:3000

**Demo Login Credentials:**
- **xsytrance** / `warroom2024`
- **juan** / `warroom2024`

### 5. Build for Production

```bash
npm run build
npm run start
```

---

## Phase 2 Testing

### How to Test the Broadcast Composer

1. **Login** at `/login` with `xsytrance` / `warroom2024`
2. **Tap BROADCAST** in the bottom nav (red button with plus icon)
3. **Select a room** from the 7 room buttons (color-coded)
4. **Optionally change signal type** — tap "Change" next to "Broadcast"
5. **Type your message** in the text area (max 2000 chars)
6. **Paste a URL** to see link detection in action
7. **Tap BROADCAST SIGNAL** (bottom) or **SEND** (top-right)
8. **Watch the pulse animation** → auto-redirect to feed
9. **See your post at the top** with correct room badge and timestamp

### API Tests (curl)

```bash
# 1. Login
curl -c cookies.txt -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"xsytrance","password":"warroom2024"}'

# 2. Create a broadcast
curl -b cookies.txt -X POST http://localhost:3000/api/posts \
  -H "Content-Type: application/json" \
  -d '{"body":"Test broadcast","roomId":"ROOM_ID_HERE","type":"human_broadcast"}'

# 3. Empty body should fail
curl -b cookies.txt -X POST http://localhost:3000/api/posts \
  -H "Content-Type: application/json" \
  -d '{"body":"","roomId":"ROOM_ID_HERE"}'
# → {"error":"Message body is required"}

# 4. Invalid room should fail
curl -b cookies.txt -X POST http://localhost:3000/api/posts \
  -H "Content-Type: application/json" \
  -d '{"body":"test","roomId":"invalid"}'
# → {"error":"Invalid room — room not found"}

# 5. Unauthenticated should fail
curl -X POST http://localhost:3000/api/posts \
  -H "Content-Type: application/json" \
  -d '{"body":"test","roomId":"x"}'
# → {"error":"Unauthorized"}
```

---

## Project Structure

```
war-room/
├── prisma/
│   ├── schema.prisma       # Database schema (User, Room, Post, Comment, Reaction, Agent)
│   ├── seed.ts             # Demo data seed script
│   └── migrations/           # Database migrations
├── src/
│   ├── app/                  # Next.js App Router
│   │   ├── api/              # API Routes
│   │   │   ├── auth/         # Login, Logout, Me
│   │   │   ├── posts/        # Posts CRUD (GET list, POST create)
│   │   │   ├── comments/     # Comments CRUD
│   │   │   ├── reactions/    # Reactions toggle
│   │   │   ├── rooms/        # Rooms list
│   │   │   └── agents/       # Agents list
│   │   ├── broadcast/        # **Broadcast Composer (Phase 2)**
│   │   ├── feed/             # Intel Feed page
│   │   ├── rooms/            # Rooms directory page
│   │   ├── agents/           # Agents page
│   │   ├── profile/          # User profile page
│   │   ├── settings/         # App settings page
│   │   ├── login/            # Login page
│   │   ├── page.tsx          # Home (redirects)
│   │   ├── layout.tsx        # Root layout with PWA metadata
│   │   └── globals.css       # Tactical theme + animations
│   ├── components/
│   │   ├── BottomNav.tsx     # Bottom nav with BROADCAST button
│   │   ├── motion/           # VFX components
│   │   │   ├── ParticleField.tsx
│   │   │   ├── TacticalGrid.tsx
│   │   │   ├── RadarSweep.tsx
│   │   │   ├── SignalPulse.tsx      # Broadcast success animation
│   │   │   ├── Scanlines.tsx
│   │   │   ├── GlitchText.tsx
│   │   │   ├── useReducedMotion.ts  # Motion preference hook
│   │   │   └── index.ts
│   │   └── ...               # Feed cards, reaction bars, etc.
│   ├── lib/
│   │   ├── db.ts             # Prisma client singleton
│   │   ├── auth.ts           # Session utilities
│   │   └── utils.ts          # cn() helper
│   └── proxy.ts              # Route protection (auth middleware)
├── public/
│   ├── icons/                # PWA icons (72x72 to 512x512)
│   ├── manifest.json         # PWA manifest
│   └── avatars/              # Placeholder avatar images
├── .env                      # Environment variables
├── next.config.ts            # Next.js config (standalone output)
├── package.json
└── tsconfig.json
```

---

## Current Features (Phase 0 + 1 + 2)

### Authentication
- [x] Username/password login with bcrypt
- [x] JWT session cookies (httpOnly, secure)
- [x] Route protection via proxy middleware
- [x] Auto-redirect unauthenticated users to login
- [x] Logout with session destruction

### Mobile Shell
- [x] Mobile-first layout with safe-area support
- [x] Bottom navigation (Feed, Rooms, Agents, Profile) + prominent **BROADCAST** button
- [x] PWA manifest and install support
- [x] Dark tactical theme (near-black, red, cyan, green accents)

### Intel Feed
- [x] Broadcast cards with author, room badge, timestamp
- [x] Text posts with full CRUD API
- [x] **URL auto-linking** — URLs in post body render as clickable cyan links
- [x] Room filtering with pill selector
- [x] Real-time feed refresh after posting (auto-redirect to feed)
- [x] Demo posts seeded (8 posts)

### Broadcast Composer (Phase 2 — NEW)
- [x] **Dedicated /broadcast page** with full-screen mobile composer
- [x] **Room selector** — all 7 rooms with color-coded buttons
- [x] **Signal type selector** — Broadcast, Agent Report, Art Drop, Build Log, Research, IoT Event
- [x] **Text area** with 2000 character limit, real-time counter
- [x] **Link detection** — auto-detects URLs in message body, shows preview
- [x] **Submit validation** — disabled when empty, loading state while transmitting
- [x] **Error handling** — clear inline errors for invalid room, empty body, network issues
- [x] **Success animation** — SignalPulse overlay with "SIGNAL SENT" confirmation
- [x] **Auto-redirect** to feed after successful broadcast
- [x] **Cancel with discard confirmation** if text entered
- [x] Reduced-motion support throughout

### Reactions & Comments
- [x] 5 reaction types: Salute, Fire, Laugh, Mind Blown, Approved
- [x] Reaction toggle API
- [x] Comments with author
- [x] Comment count on posts

### Rooms
- [x] 7 rooms: General, AI Starter Kit, Agent Actions, Art Studio, IoT Lab, Research, Random
- [x] Room directory page with color coding
- [x] Filter feed by room

### Agents (Foundation)
- [x] 4 seeded agents: VG God, Picasso, Ultron, Juan's Deployment Agent
- [x] Agents page with status cards
- [x] Agent model ready for future API integration

### Visual Effects
- [x] Animated particle background
- [x] Tactical grid overlay
- [x] Radar sweep component
- [x] Signal pulse animation (used in broadcast success)
- [x] Scanline overlay
- [x] Glitch text effect
- [x] Reduced motion support throughout

### Settings
- [x] Sound effects toggle (placeholder)
- [x] Reduced motion toggle
- [x] Logout button

---

## Deployment Notes

### Running on PRIME / VPS

```bash
# Build
npm run build

# Start production server
npm run start
# or
PORT=3000 node .next/standalone/server.js
```

### Tailscale Access

1. Install Tailscale on the server
2. Run the app on a local port (e.g., 3000)
3. Access via the server's Tailscale IP: `http://100.x.x.x:3000`
4. No public internet exposure required

### Systemd Service (Example)

Create `/etc/systemd/system/war-room.service`:

```ini
[Unit]
Description=The War Room
After=network.target

[Service]
Type=simple
User=xsytrance
WorkingDirectory=/home/xsytrance/war-room
ExecStart=/usr/bin/npm run start
Restart=on-failure
Environment=NODE_ENV=production
Environment=NEXTAUTH_SECRET=your-production-secret

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable war-room
sudo systemctl start war-room
```

### Environment Variables for Production

```env
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="long-random-string-min-32-chars"
NODE_ENV="production"
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login, sets session cookie |
| POST | `/api/auth/logout` | Logout, clears cookie |
| GET | `/api/auth/me` | Get current user |
| GET | `/api/posts?roomId=` | List posts (optionally filtered) |
| POST | `/api/posts` | **Create a broadcast** |
| GET | `/api/comments?postId=` | List comments for post |
| POST | `/api/comments` | Create a comment |
| POST | `/api/reactions` | Toggle reaction |
| DELETE | `/api/reactions` | Remove reaction |
| GET | `/api/rooms` | List all rooms |
| GET | `/api/agents` | List all agents |

### POST /api/posts Payload

```json
{
  "roomId": "room-uuid",
  "body": "Your broadcast message",
  "type": "human_broadcast",
  "mediaUrl": null,
  "mediaType": null,
  "linkUrl": null
}
```

Validation:
- `body` is required and must be non-empty (max 2000 chars)
- `roomId` is required and must be a valid room
- `type` defaults to `human_broadcast`
- Returns 201 with created post on success
- Returns 400 with specific error message on validation failure
- Returns 401 if unauthenticated

### Future Agent API (Phase 6+)

```
POST /api/agent/broadcast
Authorization: Bearer <agent-token>
Body: {
  "agent": "picasso",
  "room": "art-studio",
  "type": "art_drop",
  "title": "New image generated",
  "body": "...",
  "mediaUrl": "/uploads/example.png",
  "priority": "normal",
  "metadata": { "model": "Flux", "prompt": "...", "seed": "12345" }
}
```

---

## Database Schema

```prisma
model User {
  id, username, displayName, passwordHash, avatarUrl, roleTitle, status
  posts, comments, reactions
}

model Room {
  id, name, slug, description, icon, color
  posts
}

model Post {
  id, authorId, roomId, type, title, body
  mediaUrl, mediaType, linkUrl, metadataJson, priority
  author, room, comments, reactions
}

model Comment {
  id, postId, authorId, body
  post, author
}

model Reaction {
  id, postId, userId, emoji, label
  post, user
}

model Agent {
  id, name, slug, roleTitle, avatarUrl, status, apiTokenHash
}
```

---

## Post Types

| Type | Purpose |
|------|---------|
| `human_broadcast` | Regular user post |
| `agent_report` | Agent status/mission update |
| `art_drop` | Generated artwork |
| `music_drop` | Generated music |
| `research_find` | Research discovery |
| `build_log` | Build/deployment update |
| `iot_event` | IoT device event |
| `alert` | Urgent notification |
| `mission_update` | Mission status change |
| `file_drop` | Shared file/document |

---

## Phase Roadmap

| Phase | Status | Goal |
|-------|--------|------|
| 0 | Complete | Project scaffold, Prisma schema, seed data, PWA config |
| 1 | Complete | Auth, mobile shell, tactical theme, visual effects |
| 2 | **Complete** | **Broadcast composer, create post API, link detection, feed refresh** |
| 3 | Planned | Media uploads (image + lightbox), reply threads polish |
| 4 | Planned | PWA polish + service worker + install flow |
| 5 | Planned | Agent posting API + agent auth tokens |
| 6 | Planned | Docker + systemd + Tailscale deployment docs |

---

## Known Limitations (Phase 2)

- Media upload is stubbed (images display via URL only, no file upload yet)
- Real-time updates require manual refresh or navigation (WebSockets planned)
- Push notifications require service worker (planned)
- Agent API is documented but not fully implemented (Phase 5+)
- No image upload or drag-and-drop (Phase 3+)
- No threaded comment replies (Phase 3+)

---

## Security Notes

- App requires login for all routes except `/login` and auth APIs
- Passwords hashed with bcrypt (10 rounds)
- JWT sessions in httpOnly cookies
- No public registration (invite-only future)
- SQLite file should be backed up regularly
- Run behind Tailscale or VPN for private access
- Change `NEXTAUTH_SECRET` for production
- Empty posts rejected server-side
- Invalid room IDs rejected server-side
- All API routes validate authentication

---

## Credits

Built for **xsytrance** and **Juan** by the Kimi AI Swarm.

**Phase 2: Broadcast Composer is LIVE.**

Tactical design. Mobile-first. Private by default.
