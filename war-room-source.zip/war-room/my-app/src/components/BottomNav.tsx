'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Radio, LayoutGrid, PlusCircle, Bot, User } from 'lucide-react';

const navItems = [
  { href: '/feed', label: 'Feed', icon: Radio },
  { href: '/rooms', label: 'Rooms', icon: LayoutGrid },
  { href: '/agents', label: 'Agents', icon: Bot },
  { href: '/profile', label: 'Profile', icon: User },
];

export default function BottomNav() {
  const pathname = usePathname();

  // Don't show nav on broadcast page (composer is full-screen)
  if (pathname === '/broadcast') return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#0a0a0f]/90 backdrop-blur-md border-t border-white/10 safe-bottom">
      <div className="max-w-2xl mx-auto flex items-center justify-around px-2 py-2 pb-[max(0.5rem,env(safe-area-inset-bottom))]">
        {navItems.map((item, index) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/');
          const Icon = item.icon;
          
          // Insert Broadcast button in the middle
          if (index === 2) {
            return (
              <div key="broadcast-group" className="flex items-center gap-1">
                <Link
                  href={item.href}
                  className={`flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-lg transition-all ${
                    isActive
                      ? 'text-cyan-400 bg-cyan-500/10'
                      : 'text-white/30 hover:text-white/60'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-[10px] font-medium tracking-wide">{item.label}</span>
                </Link>
              </div>
            );
          }

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-lg transition-all ${
                isActive
                  ? 'text-cyan-400 bg-cyan-500/10'
                  : 'text-white/30 hover:text-white/60'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-medium tracking-wide">{item.label}</span>
            </Link>
          );
        })}

        {/* Center Broadcast Button - Always visible, distinct styling */}
        <Link
          href="/broadcast"
          className="flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-xl transition-all -mt-3 bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/30 hover:bg-[#ef4444]/30 active:scale-95"
        >
          <PlusCircle className="w-7 h-7" strokeWidth={2} />
          <span className="text-[10px] font-bold tracking-wide">BROADCAST</span>
        </Link>
      </div>
    </nav>
  );
}
