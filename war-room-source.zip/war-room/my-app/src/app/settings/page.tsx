'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Shield, Moon, Bell, Lock, LogOut } from 'lucide-react';
import Link from 'next/link';
import BottomNav from '@/components/BottomNav';

interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  roleTitle: string;
  status: string;
}

export default function SettingsPage() {
  const [profile, setProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => setProfile(data.user || null));
  }, []);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    window.location.href = '/login';
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-[#0a0a0f]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-3">
          <Link href="/profile" className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
            <ArrowLeft className="w-4 h-4 text-white/50" />
          </Link>
          <h1 className="text-lg font-bold tracking-wider uppercase text-cyan-400">
            SETTINGS
          </h1>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
        {/* User Section */}
        {profile && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#12121a] border border-white/10 rounded-xl p-4"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center font-bold">
                {profile.displayName.charAt(0)}
              </div>
              <div>
                <p className="text-sm font-semibold text-white">{profile.displayName}</p>
                <p className="text-xs text-white/40">{profile.roleTitle}</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Toggles */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[#12121a] border border-white/10 rounded-xl overflow-hidden"
        >
          <div className="p-4 flex items-center justify-between border-b border-white/5">
            <div className="flex items-center gap-3">
              <Moon className="w-4 h-4 text-cyan-400" />
              <span className="text-sm text-white/80">Dark Mode</span>
            </div>
            <div className="w-10 h-6 bg-cyan-500/30 rounded-full relative">
              <div className="absolute right-1 top-1 w-4 h-4 bg-cyan-400 rounded-full" />
            </div>
          </div>
          <div className="p-4 flex items-center justify-between border-b border-white/5">
            <div className="flex items-center gap-3">
              <Bell className="w-4 h-4 text-amber-400" />
              <span className="text-sm text-white/80">Notifications</span>
            </div>
            <div className="w-10 h-6 bg-white/10 rounded-full relative">
              <div className="absolute left-1 top-1 w-4 h-4 bg-white/30 rounded-full" />
            </div>
          </div>
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Lock className="w-4 h-4 text-emerald-400" />
              <span className="text-sm text-white/80">Secure Mode</span>
            </div>
            <div className="w-10 h-6 bg-cyan-500/30 rounded-full relative">
              <div className="absolute right-1 top-1 w-4 h-4 bg-cyan-400 rounded-full" />
            </div>
          </div>
        </motion.div>

        {/* Security */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[#12121a] border border-white/10 rounded-xl p-4"
        >
          <h3 className="text-xs uppercase tracking-wider text-white/40 mb-3">Security</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-white/60">Session</span>
              <span className="text-xs text-emerald-400">Active</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-white/60">Encryption</span>
              <span className="text-xs text-cyan-400">AES-256</span>
            </div>
          </div>
        </motion.div>

        {/* Logout */}
        <motion.button
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          onClick={handleLogout}
          className="w-full bg-[#12121a] border border-red-500/20 rounded-xl p-4 flex items-center justify-center gap-2 text-red-400 hover:bg-red-500/10 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span className="text-sm font-medium">Terminate Session</span>
        </motion.button>
      </div>

      <BottomNav />
    </div>
  );
}
