'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, FileText, Heart, Shield, Activity } from 'lucide-react';
import Link from 'next/link';

import BottomNav from '@/components/BottomNav';

interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  roleTitle: string;
  status: string;
  postsCount: number;
  reactionsGiven: number;
}

function getRoleColor(role: string) {
  switch (role.toLowerCase()) {
    case 'command': return 'text-amber-400 border-amber-400/30 bg-amber-400/10';
    case 'infiltrator': return 'text-emerald-400 border-emerald-400/30 bg-emerald-400/10';
    case 'sniper': return 'text-red-400 border-red-400/30 bg-red-400/10';
    case 'hacker': return 'text-violet-400 border-violet-400/30 bg-violet-400/10';
    default: return 'text-cyan-400 border-cyan-400/30 bg-cyan-400/10';
  }
}

export default function ProfilePage() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        setProfile(data.user || null);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white flex items-center justify-center">
        <div className="text-white/30 text-sm">Loading profile...</div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-white/40 text-sm">Not authenticated</p>
          <Link href="/login" className="text-cyan-400 text-sm mt-2 inline-block hover:underline">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-[#0a0a0f]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-lg font-bold tracking-wider uppercase text-cyan-400">
            OPERATIVE PROFILE
          </h1>
          <Link
            href="/settings"
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
          >
            <Settings className="w-4 h-4 text-white/50" />
          </Link>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Identity Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="bg-[#12121a] border border-white/10 rounded-xl p-6"
        >
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-2xl font-bold shrink-0">
              {profile.displayName.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-xl font-bold text-white">{profile.displayName}</h2>
              <p className="text-sm text-white/40">@{profile.username}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 rounded border ${getRoleColor(profile.roleTitle)}`}>
                  {profile.roleTitle}
                </span>
                <div className="flex items-center gap-1">
                  <Activity className="w-3 h-3 text-emerald-400" />
                  <span className="text-[10px] text-white/40 uppercase tracking-wider">{profile.status}</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="grid grid-cols-2 gap-3 mt-4"
        >
          <div className="bg-[#12121a] border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="w-4 h-4 text-cyan-400" />
              <span className="text-xs text-white/40 uppercase tracking-wider">Broadcasts</span>
            </div>
            <p className="text-2xl font-bold text-white">{profile.postsCount}</p>
          </div>
          <div className="bg-[#12121a] border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Heart className="w-4 h-4 text-rose-400" />
              <span className="text-xs text-white/40 uppercase tracking-wider">Reactions</span>
            </div>
            <p className="text-2xl font-bold text-white">{profile.reactionsGiven}</p>
          </div>
        </motion.div>

        {/* Tactical Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="bg-[#12121a] border border-white/10 rounded-xl p-4 mt-4"
        >
          <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
            <Shield className="w-4 h-4 text-cyan-400" />
            OPERATIVE DETAILS
          </h3>
          <div className="space-y-2.5">
            <div className="flex justify-between items-center">
              <span className="text-xs text-white/40">ID</span>
              <span className="text-xs text-white/60 font-mono">{profile.id.slice(0, 8)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs text-white/40">Role</span>
              <span className="text-xs text-white/60">{profile.roleTitle}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs text-white/40">Status</span>
              <span className="text-xs text-emerald-400">{profile.status}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs text-white/40">Clearance</span>
              <span className="text-xs text-amber-400">Level 4</span>
            </div>
          </div>
        </motion.div>
      </div>

      <BottomNav />
    </div>
  );
}
