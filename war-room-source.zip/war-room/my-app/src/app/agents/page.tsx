'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Bot, Wifi, WifiOff, Clock, AlertTriangle } from 'lucide-react';

import BottomNav from '@/components/BottomNav';

interface Agent {
  id: string;
  name: string;
  slug: string;
  roleTitle: string;
  avatarUrl: string | null;
  status: string;
}

export default function AgentsPage() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/agents')
      .then((res) => res.json())
      .then((data) => {
        setAgents(data.agents || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'online': return 'bg-emerald-400';
      case 'offline': return 'bg-red-400';
      case 'busy': return 'bg-amber-400';
      default: return 'bg-white/30';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'online': return <Wifi className="w-3 h-3 text-emerald-400" />;
      case 'offline': return <WifiOff className="w-3 h-3 text-red-400" />;
      default: return <Clock className="w-3 h-3 text-amber-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-[#0a0a0f]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <h1 className="text-lg font-bold tracking-wider uppercase text-cyan-400">
            ACTIVE AGENTS
          </h1>
          <p className="text-xs text-white/40 mt-1">Autonomous operatives and synthetic units</p>
        </div>
      </div>

      {/* Agents List */}
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-3">
        {loading ? (
          <div className="text-center py-12 text-white/30 text-sm">Loading agents...</div>
        ) : (
          agents.map((agent, index) => (
            <motion.div
              key={agent.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: index * 0.08 }}
              className="bg-[#12121a] border border-white/10 rounded-xl p-4 hover:border-white/20 transition-all"
            >
              <div className="flex items-start gap-4">
                {/* Avatar */}
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500/20 to-fuchsia-500/20 border border-violet-500/20 flex items-center justify-center shrink-0">
                  <Bot className="w-6 h-6 text-violet-400" />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-semibold text-white">{agent.name}</h2>
                    <div className={`w-2 h-2 rounded-full ${getStatusColor(agent.status)}`} />
                  </div>
                  <p className="text-xs text-white/40 mt-0.5">{agent.roleTitle}</p>

                  <div className="flex items-center gap-1.5 mt-2">
                    {getStatusIcon(agent.status)}
                    <span className="text-[10px] uppercase tracking-wider text-white/40">
                      {agent.status}
                    </span>
                  </div>
                </div>
              </div>

              {/* Capability Note */}
              <div className="mt-3 pt-3 border-t border-white/5 flex items-center gap-2">
                <AlertTriangle className="w-3 h-3 text-amber-400/60" />
                <span className="text-[10px] text-white/30">
                  Agent posting API coming in Phase 6
                </span>
              </div>
            </motion.div>
          ))
        )}
      </div>

      <BottomNav />
    </div>
  );
}
